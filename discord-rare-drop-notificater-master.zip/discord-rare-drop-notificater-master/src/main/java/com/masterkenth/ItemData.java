package com.masterkenth;

public class ItemData
{
	public Integer ItemId;
	public Integer GePrice;
	public int HaPrice;

	public float Rarity = 1f;
	public boolean Unique = false;
}
