package com.masterkenth;

public class RarityItemData
{
	public float Rarity;
	public boolean Unique;
}
